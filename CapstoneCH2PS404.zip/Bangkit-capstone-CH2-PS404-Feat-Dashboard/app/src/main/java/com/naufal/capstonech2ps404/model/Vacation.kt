package com.naufal.capstonech2ps404.model

data class Vacation(
    val id:String,
    val name: String,
    val description:String,
    val photoUrl: String,
    val kota: String
)

