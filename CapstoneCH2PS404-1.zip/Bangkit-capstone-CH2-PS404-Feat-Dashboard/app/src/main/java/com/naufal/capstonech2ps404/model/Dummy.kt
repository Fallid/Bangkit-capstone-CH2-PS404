package com.naufal.capstonech2ps404.model

object Dummy {
    val vacations = listOf(
        Vacation(
            "1",
            "Borobudur Temple",
            "Candi Borobudur adalah sebuah candi Buddha yang terletak di Magelang, Jawa Tengah, Indonesia. Candi ini merupakan salah satu keajaiban arsitektur dunia dan menjadi tempat ziarah agama Buddha.",
            "https://upload.wikimedia.org/wikipedia/commons/8/8c/Borobudur-Nothwest-view.jpg",
            "4.5 out of 5",
            "45$",
            "10day"
        ),
        Vacation(
            "2",
            "Komodo Island",
            "Pulau Komodo terkenal karena menjadi rumah bagi kadal komodo, salah satu spesies kadal terbesar di dunia. Pulau ini juga menawarkan keindahan alam bawah laut yang menakjubkan.",
            "https://upload.wikimedia.org/wikipedia/commons/e/e3/Komodo_Island_north_aerial.jpg",
            "4.5 out of 5",
            "45$",
            "10day"
        ),
        Vacation(
            "3",
            "Raja Ampat",
            "Raja Ampat adalah destinasi penyelaman yang sangat populer di Indonesia. Terkenal dengan keindahan terumbu karangnya, Raja Ampat menjadi surga bagi para penyelam dan pecinta alam bawah laut.",
            "https://upload.wikimedia.org/wikipedia/commons/8/88/Raja_Ampat%2C_Mutiara_Indah_di_Timur_Indonesia.jpg",
            "4.5 out of 5",
            "45$",
            "10day"
        ),
        Vacation(
            "4",
            "Tana Toraja",
            "Tana Toraja adalah daerah di Sulawesi Selatan yang terkenal dengan kebudayaan uniknya, termasuk rumah adat berbentuk tongkonan dan upacara pemakaman yang khas.",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbpepmrARs2ZPnDfQbaOcVtQWT-KkZVtRFpffPGns3Cg&s",
            "4.5 out of 5",
            "45$",
            "10day"
        ),

        Vacation(
            "10",
            "Prambanan Temple",
            "Candi Prambanan adalah kompleks candi Hindu terbesar di Indonesia, terletak di Yogyakarta. Candi ini merupakan contoh arsitektur candi Hindu yang megah dan indah.",
            "https://upload.wikimedia.org/wikipedia/commons/0/0b/Prambanan_Temple_Yogyakarta_Indonesia.jpg",
            "4.5 out of 5",
            "45$",
            "10day"
        )
    )
}
