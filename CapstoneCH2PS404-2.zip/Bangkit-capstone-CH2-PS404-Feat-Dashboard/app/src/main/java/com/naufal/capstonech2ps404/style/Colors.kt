package com.naufal.capstonech2ps404.style

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val primaryColor = Color(0xFF40B59F)
val PurpleGrey40 = Color(0xFF40B59F)
val onSurface = Color(0xFFBECCE3)
val backgroundColor = Color(0xFFFFFFFF)