package com.naufal.tugasss.domain

import com.naufal.tugasss.data.local.model.VacationEntity

data class Vacation(
    val id: String,
    val name: String,
    val description: String,
    val photoUrl: String,
    val rating: String,
    val price: String,
    val duration: String,
    val city: String,
    var isListed: Boolean = false,
)

fun VacationEntity.toVacation() = Vacation(
    id, name, description, photoUrl, rating, price, duration, city, isListed
)