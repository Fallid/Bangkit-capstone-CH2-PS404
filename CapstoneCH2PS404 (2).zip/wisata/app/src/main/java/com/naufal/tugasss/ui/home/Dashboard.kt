package com.naufal.tugasss.ui.home

import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.naufal.tugasss.data.Dummy
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.state.UiState
import com.naufal.tugasss.style.AppTheme
import com.naufal.tugasss.style.backgroundColor
import com.naufal.tugasss.viewmodel.DashboardViewModel

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigateToDetail: (String) -> Unit,
) {
    val query by viewModel.query

    viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
        when(uiState) {
            is UiState.Loading -> {
                viewModel.getVacations()
            }

            is UiState.Success -> {
                Scaffold(
                    topBar = { SearchBarLayout(query = query, onQueryChange = {
                        viewModel.onUpdateQuery(it)
                        viewModel.getSearchVacations()
                    }) },
                ) { innerPadding ->

                    if (uiState.data.isEmpty()) {
                        //handle empty
                    } else {
                        DashboardContent(
                            vacations = uiState.data,
                            onNavigateToDetail = onNavigateToDetail,
                            modifier = Modifier
                            .padding(innerPadding)
                        )
                    }


                }
            }
            is UiState.Error -> {
                //handle error
            }
        }
    }
}



@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DashboardContent(
    vacations: List<Vacation>,
    modifier: Modifier = Modifier,
    onNavigateToDetail: (String) -> Unit,
) {
    Column(
        modifier = modifier
            .background(backgroundColor)
    ) {

        LazyRow{
            items(vacations, key = { it.id }) { vacation ->
                VacationFavoriteItem(
                    name = vacation.name,
                    photoUrl = vacation.photoUrl,
                    kota = vacation.city,
                    onClick = {
                        onNavigateToDetail(vacation.id)
                    },
                    modifier = Modifier
                        .width(200.dp)
                        .heightIn(min = 250.dp)
                        .height(250.dp)
                        .background(backgroundColor)
                        .animateItemPlacement(tween(durationMillis = 100))
                )
            }
        }
    }
}


@Preview
@Composable
fun DashboardPreview() {
    AppTheme {
        DashboardContent(vacations = Dummy.vacations, onNavigateToDetail = {})
    }
}