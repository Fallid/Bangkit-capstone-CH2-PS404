package com.naufal.tugasss.domain

import androidx.compose.ui.graphics.painter.Painter

data class ButtonNavigationItem(
    val title: String,
    val selectedIcon: Painter,
    val unselectedIcon: Painter,
    val hasNews: Boolean,
    val badgeCount: Int? = null
)