package com.naufal.tugasss.data.local.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.naufal.tugasss.domain.Vacation

@Entity(tableName = "vacation")
data class VacationEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String,
    val photoUrl: String,
    val rating: String,
    val price: String,
    val duration: String,
    val city: String,
    val isListed: Boolean,
)

fun Vacation.toVacationEntity() = VacationEntity(
    id, name, description, photoUrl, rating, price, duration, city, isListed
)