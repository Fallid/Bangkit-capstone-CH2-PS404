package com.naufal.tugasss.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.domain.toVacation
import com.naufal.tugasss.data.local.VacationDatabase
import com.naufal.tugasss.data.local.model.toVacationEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class VacationRepository(
    private val vacationDatabase: VacationDatabase,
    private val datastore: DataStore<Preferences>
) {
    fun getVacations() : Flow<List<Vacation>> {
        return vacationDatabase.vacationDao().getVacations().map { vacations ->
            vacations.map { entity ->
                entity.toVacation()
            }
        }
    }

    fun getListedacations() : Flow<List<Vacation>> {
        return vacationDatabase.vacationDao().getListedVacations().map { vacations ->
            vacations.map { entity ->
                entity.toVacation()
            }
        }
    }

    fun getListedVacationById(vacationId: String): Flow<Vacation?> {
        return vacationDatabase.vacationDao().getVacationById(vacationId = vacationId).map { it?.toVacation() }
    }

    fun getSearch(query: String): Flow<List<Vacation>> {
        return vacationDatabase.vacationDao().getSearch(query).map { vacations ->
            vacations.map { entity ->
                entity.toVacation()
            }
        }
    }

    suspend fun insertVacations(vacations: List<Vacation>) {
        vacationDatabase.vacationDao().insertVacations(
            vacations = vacations.map { it.toVacationEntity() }
        )
    }

    suspend fun insertVacation(vacation: Vacation) {
        vacationDatabase.vacationDao().insertVacation( vacation = vacation.toVacationEntity() )
    }

    suspend fun saveFirstimeUser(isFirstime: Boolean){
        datastore.edit { preferences ->
            preferences[FIRSTIME_USER] = isFirstime
        }
    }

    fun getFirstimeuser(): Flow<Boolean?> {
        return datastore.data.map { preferences ->
            preferences[FIRSTIME_USER]
        }
    }

    companion object {
        private val FIRSTIME_USER = booleanPreferencesKey("firstime_user")
    }
}