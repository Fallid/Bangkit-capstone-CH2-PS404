package com.naufal.tugasss.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.naufal.tugasss.data.local.model.VacationEntity

@Database(
    entities = [VacationEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VacationDatabase: RoomDatabase() {

    abstract fun vacationDao(): VacationDao
}