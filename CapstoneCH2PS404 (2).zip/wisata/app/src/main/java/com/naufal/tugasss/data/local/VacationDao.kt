package com.naufal.tugasss.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.naufal.tugasss.data.local.model.VacationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VacationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVacation(vacation: VacationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVacations(vacations: List<VacationEntity>)

    @Query("SELECT * FROM vacation WHERE id = :vacationId LIMIT 1")
    fun getVacationById(vacationId: String) : Flow<VacationEntity?>

    @Query("SELECT * FROM  vacation WHERE isListed = 1")
    fun getListedVacations(): Flow<List<VacationEntity>>

    @Query("SELECT * FROM vacation ORDER BY id")
    fun getVacations(): Flow<List<VacationEntity>>

    @Query("SELECT * FROM vacation WHERE name like '%' || :query || '%' ")
    fun getSearch(query: String): Flow<List<VacationEntity>>
}