package com.naufal.tugasss.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naufal.tugasss.data.VacationRepository
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.state.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailVacationViewModel @Inject constructor(
    private val vacationRepository: VacationRepository
): ViewModel() {
    private var _uiState: MutableStateFlow<UiState<Vacation>> = MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<Vacation>> get() = _uiState


    fun insertListedVacation(vacation: Vacation) {
        viewModelScope.launch {
            vacationRepository.insertVacation(vacation = vacation)
        }
    }
    fun getVacationById(vacationId: String) {
        _uiState.value = UiState.Loading
        try {
            viewModelScope.launch {
                vacationRepository.getListedVacationById(vacationId = vacationId)
                    .catch {
                        _uiState.value = UiState.Error(it.message.toString())
                    }
                    .collect {
                        if(it == null) {
                            _uiState.value = UiState.Error("Cannot find data")
                        } else {
                            _uiState.value = UiState.Success(it)
                        }
                    }
            }
        } catch (e: Exception) {
            _uiState.value = UiState.Error(e.message.toString())
        }
    }
}