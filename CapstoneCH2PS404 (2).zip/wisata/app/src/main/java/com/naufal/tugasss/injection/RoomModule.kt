package com.naufal.tugasss.injection

import android.content.Context
import androidx.room.Room
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.data.local.VacationDao
import com.naufal.tugasss.data.local.VacationDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class RoomModule {
    @Provides
    fun providesVacationDao(vacationDatabase: VacationDatabase): VacationDao = vacationDatabase.vacationDao()

    @Provides
    @Singleton
    fun provideVacationDatabase(@ApplicationContext context: Context): VacationDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            VacationDatabase::class.java,
            "vacation_database"
        ).build()
    }
}