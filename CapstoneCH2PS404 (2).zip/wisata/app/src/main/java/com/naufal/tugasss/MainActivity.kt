package com.naufal.tugasss

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlendMode.Companion.Screen
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.naufal.capstonech2ps404.R
import com.naufal.tugasss.data.Dummy
import com.naufal.tugasss.state.UiState
import com.naufal.tugasss.style.AppTheme
import com.naufal.tugasss.ui.detail.DetailVacationScreen
import com.naufal.tugasss.ui.favorite.Favorite
import com.naufal.tugasss.ui.home.DashboardScreen
import com.naufal.tugasss.ui.home.FabDashboard
import com.naufal.tugasss.ui.notification.Notification
import com.naufal.tugasss.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                val navController = rememberNavController()
                val viewModel: MainViewModel = hiltViewModel()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
                    when (uiState) {
                        is UiState.Loading -> {
                            viewModel.getFirstimeUser()
                        }

                        is UiState.Success -> {
                            if (uiState.data == null || uiState.data) {
                                viewModel.saveFirsttimeUser(false)
                                viewModel.insertVacations(Dummy.vacations)
                            } else {
                                //handle error
                            }

                            Surface(
                                modifier = Modifier.fillMaxSize(),
                                color = MaterialTheme.colorScheme.background
                            ) {
                                Scaffold(
                                    floatingActionButton = {
                                        if (currentRoute != "vacation/{vacationId}") {
                                            FabDashboard(navController = navController)
                                        }
                                    }
                                ) {
                                        innerPadding->
                                    NavHost(navController = navController, startDestination = "Home", modifier = Modifier.padding(innerPadding) ){

                                        composable("Home"){ DashboardScreen(onNavigateToDetail = { vacationId ->
                                            navController.navigate("vacation/$vacationId")
                                        }) }

                                        composable("Notification"){ Notification()}

                                        composable("Favorite"){ Favorite() }

                                        composable(
                                            route = "vacation/{vacationId}"
                                        ) {
                                            val id = it.arguments?.getString("vacationId").toString()
                                            DetailVacationScreen(vacationId = id) {
                                                navController.navigateUp()
                                            }

                                        }
                                    }
                                }
                            }
                        }

                        is UiState.Error -> {
                            //handle error
                        }
                    }
                }
            }
        }
    }
}