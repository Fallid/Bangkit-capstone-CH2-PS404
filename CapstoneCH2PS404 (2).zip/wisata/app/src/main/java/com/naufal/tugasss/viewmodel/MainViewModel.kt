package com.naufal.tugasss.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naufal.tugasss.data.VacationRepository
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.state.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val vacationRepository: VacationRepository
): ViewModel() {
    private val _uiState: MutableStateFlow<UiState<Boolean?>> = MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<Boolean?>> get() = _uiState

    fun getFirstimeUser() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            try {
                vacationRepository.getFirstimeuser()
                    .catch {
                        _uiState.value = UiState.Error(it.message.toString())
                    }
                    .collect {
                        _uiState.value = UiState.Success(it ?: true)
                    }
            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.message.toString())
            }
        }
    }

    fun saveFirsttimeUser(isFirstime: Boolean) {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            vacationRepository.saveFirstimeUser(isFirstime)
        }
    }

    fun insertVacations(vacations: List<Vacation>) {
        viewModelScope.launch {
            vacationRepository.insertVacations(vacations)
        }
    }
}