package com.naufal.tugasss.style

import com.naufal.capstonech2ps404.R
//import com.naufal.tugasss.R

object IconsApp{
    val icCompas = R.drawable.ic_compas
    val icNotification = R.drawable.ic_notification
    val icFavorite = R.drawable.ic_favorite
}
