package com.naufal.tugasss.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naufal.tugasss.data.VacationRepository
import com.naufal.tugasss.domain.Vacation
import com.naufal.tugasss.state.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val vacationRepository: VacationRepository
): ViewModel() {
    private val _uiState: MutableStateFlow<UiState<List<Vacation>>> = MutableStateFlow(UiState.Loading)
    val uiState: StateFlow<UiState<List<Vacation>>> get() = _uiState

    private val _query = mutableStateOf("")
    val query: State<String> get() = _query

    fun onUpdateQuery(query: String) {
        _query.value = query
    }

    fun getVacations() {
        viewModelScope.launch {
            try {
                vacationRepository.getVacations()
                    .catch {
                        _uiState.value = UiState.Error(it.message.toString())
                    }
                    .collect {
                        _uiState.value = UiState.Success(it)
                    }
            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.message.toString())
            }
        }
    }

    fun getSearchVacations() {
        if (query.value.isEmpty()) {
            getVacations()
        } else {
            viewModelScope.launch {
                try {
                    vacationRepository.getSearch(query.value)
                        .catch {
                            _uiState.value = UiState.Error(it.message.toString())
                        }
                        .collect {
                            _uiState.value = UiState.Success(it)
                        }
                } catch (e: Exception) {
                    _uiState.value = UiState.Error(e.message.toString())
                }
            }
        }
    }
}